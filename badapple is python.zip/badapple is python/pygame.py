import cv2
import numpy as np
import os
import time
from concurrent.futures import ThreadPoolExecutor

# 動画ファイルのパス
video_path = '【東方】Bad Apple!! ＰＶ【影絵】.mp4'

# アスキーアート用の文字
ASCII_CHARS = "@%#*+=-:. "

# 速度係数（1.3で30%速く）
SPEED_FACTOR = 100.0

# フレームをアスキーアートに変換する関数
def frame_to_ascii(frame, cols=120, scale=0.43):
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    height, width = gray_frame.shape

    aspect_ratio = height / width
    new_height = int(aspect_ratio * cols * scale)
    resized_frame = cv2.resize(gray_frame, (cols, new_height))

    ascii_frame = np.array([ASCII_CHARS[pixel // 32] for pixel in resized_frame.flatten()]).reshape(new_height, cols)
    return '\n'.join([''.join(row) for row in ascii_frame])

# 動画をフレームごとに読み込み、アスキーアートに変換する
def video_to_ascii(video_path, speed_factor=SPEED_FACTOR):
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_time = 1 / (fps * speed_factor)  # 速度係数を適用

    with ThreadPoolExecutor(max_workers=4) as executor:
        while cap.isOpened():
            start_time = time.time()
            ret, frame = cap.read()
            if not ret:
                break

            future = executor.submit(frame_to_ascii, frame)

            process_time = time.time() - start_time
            wait_time = max(0, frame_time - process_time)
            time.sleep(wait_time)

            os.system('cls' if os.name == 'nt' else 'clear')
            print(future.result())

    cap.release()

# 動画をアスキーアートに変換（30%速く）
video_to_ascii(video_path)